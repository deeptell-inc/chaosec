# Declarations

**Title:** Chaotic states outperform quantum many-body scars as codes under
generic measurement: a refutation of scar-enhanced information protection

**Authors:** Hikaru Wakaura, Taiki Tanimae
(QIRI — Quantum Integrated Research Institute Inc., Tokyo 107-0061, Japan)

## Competing interests
The authors declare no competing interests.

## Funding
[To be completed by the authors before submission. If none: "This research
received no specific grant from any funding agency."]

## Author contributions
Both authors contributed to the conception, computation, analysis, and writing.
[Refine per author preference before submission.]

## Data and code availability
All simulation code (`scarcode`), reproduction drivers, and the data underlying
every figure are openly available; the repository will be archived at a Zenodo
DOI upon publication. A statement to this effect appears in the manuscript.

## Ethics
Not applicable (theoretical/computational study; no human or animal subjects).
